(function(){
const {h,$,$$,reduce,lerp}=Core;
function rng(seed){ return function(){ seed|=0; seed=seed+0x6D2B79F5|0; let t=Math.imul(seed^seed>>>15,1|seed); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
/* รันแอนิเมชันเฉพาะตอนมองเห็น */
function whenVisible(el,fn){
  let raf=null,last=0,vis=false;
  const loop=ts=>{ const dt=Math.min(.05,(ts-last)/1000); last=ts; fn(dt,ts/1000); raf=requestAnimationFrame(loop); };
  const io=new IntersectionObserver(es=>{ vis=es[0].isIntersecting; if(vis&&!raf&&!reduce){ last=performance.now(); raf=requestAnimationFrame(loop); } if(!vis&&raf){ cancelAnimationFrame(raf); raf=null; } },{threshold:.05});
  io.observe(el); if(reduce) fn(0,0);
}

/* =============== 1) สะพานข้อมูล =============== */
(function(){
  const svg=$('#bridge-svg'), cap=$('#bcap');
  const X0=215,X1=685,CY=170,A=54;
  const STEPS=[
    {b:'1 ตั้งคำถาม', c:'เริ่มจากคำถาม: ทำไมมะเร็งในสุนัขจึงดื้อต่อยา สุนัขเป็นมะเร็งเองตามธรรมชาติ ในสิ่งแวดล้อมเดียวกับเจ้าของ'},
    {b:'2 อ่านด้วยสะพานข้อมูล', c:'ใช้ single-cell RNA, spatial transcriptomics และ digital pathology อ่านว่าเซลล์มะเร็งและสิ่งรอบก้อนทำงานอย่างไร จนเห็นกลไกการดื้อยา'},
    {b:'3 ส่งความรู้ไปหาคน', c:'ถ้าเข้าใจกลไกในสุนัข ก็อาจนำไปช่วยค้นหาวิธีรักษามะเร็งคนได้ ซึ่งช่วยลดเวลาและความเสี่ยงของการพัฒนายาในคน'}
  ];
  let step=0;
  const bar=$('#bsteps');
  STEPS.forEach((s,i)=>bar.append(h('button',{type:'button','aria-pressed':i===0?'true':'false',onclick:()=>{ step=i; $$('button',bar).forEach((b,k)=>b.setAttribute('aria-pressed',k===i?'true':'false')); upd(); }},s.b)));
  const rungs=[]; for(let x=X0;x<=X1;x+=18) rungs.push(h('line',{stroke:'rgba(255,255,255,.28)','stroke-width':2}));
  const s1=h('path',{fill:'none',stroke:'var(--blue-lt)','stroke-width':4,'stroke-linecap':'round'});
  const s2=h('path',{fill:'none',stroke:'var(--red-lt)','stroke-width':4,'stroke-linecap':'round'});
  const glowD=h('circle',{class:'glow',cx:110,cy:CY,r:82,fill:'none',stroke:'var(--red-lt)','stroke-width':4,opacity:1});
  const glowH=h('circle',{class:'glow',cx:790,cy:CY,r:82,fill:'none',stroke:'var(--green-lt)','stroke-width':4,opacity:0});
  const mk=(x,n,sb)=>[h('circle',{cx:x,cy:CY,r:62,fill:'#0B1F4B',stroke:'var(--navy-lt)','stroke-width':2.5}),h('text',{class:'nm',x,y:CY+8},n),h('text',{class:'sb',x,y:CY+96},sb)];
  const chips=['single-cell RNA','spatial transcriptomics','digital pathology'].map((t,i)=>h('g',{opacity:0,style:{transition:'opacity .5s'}},h('rect',{x:300+i*0,y:0,width:0,height:0}),h('text',{x:450,y:40+i*0,'text-anchor':'middle',style:{fontSize:'14px'}},t)));
  const chipG=h('g');
  ['single-cell RNA','spatial transcriptomics','digital pathology'].forEach((t,i)=>{
    const x=[260,450,640][i];
    chipG.append(h('g',{class:'chip',opacity:0,style:{transition:'opacity .5s'}},h('rect',{x:x-82,y:26,width:164,height:30,rx:15,fill:'#0B1F4B',stroke:'var(--navy-lt)'}),h('text',{x,y:46,'text-anchor':'middle',style:{fontSize:'13.5px'}},t)));
  });
  const dots=Array.from({length:7},(_,i)=>h('circle',{r:5.5,fill:'#fff',opacity:0,'data-p':i/7}));
  svg.append(...rungs,s1,s2,glowD,glowH,...mk(110,'สุนัข','มะเร็งที่เกิดเอง'),...mk(790,'คน','ต้องการยาใหม่'),chipG,...dots);
  function draw(t){
    let d1='M',d2='M';
    for(let x=X0;x<=X1;x+=6){
      const ph=(x-X0)/120*Math.PI*2+t*1.6, y1=CY+A*Math.sin(ph), y2=CY-A*Math.sin(ph);
      d1+=(x===X0?'':' L')+x+' '+y1.toFixed(1); d2+=(x===X0?'':' L')+x+' '+y2.toFixed(1);
    }
    s1.setAttribute('d',d1); s2.setAttribute('d',d2);
    rungs.forEach((r,i)=>{ const x=X0+i*18, ph=(x-X0)/120*Math.PI*2+t*1.6, y=A*Math.sin(ph);
      r.setAttribute('x1',x); r.setAttribute('x2',x); r.setAttribute('y1',(CY+y).toFixed(1)); r.setAttribute('y2',(CY-y).toFixed(1)); r.setAttribute('opacity',(.25+.5*Math.abs(Math.cos(ph))).toFixed(2)); });
  }
  let prog=0;
  function move(dt){
    prog=(prog+dt*0.22)%1;
    dots.forEach(d=>{
      const p0=(+d.dataset.p+prog)%1;
      if(step===0){ d.setAttribute('opacity',0); return; }
      const xmax=step===1?450:X1; d.setAttribute('cx',(X0+(xmax-X0)*p0).toFixed(1)); d.setAttribute('cy',CY); d.setAttribute('opacity',.95);
    });
  }
  function upd(){
    cap.textContent=STEPS[step].c;
    glowD.setAttribute('opacity',step<2?1:.25); glowH.setAttribute('opacity',step===2?1:0);
    $$('.chip',chipG).forEach(c=>c.setAttribute('opacity',step>=1?1:0));
  }
  upd(); draw(0);
  whenVisible(svg,(dt,t)=>{ draw(t); move(dt); });
})();

/* =============== 2) ภาพชิ้นเนื้อ → AI =============== */
(function(){
  const svg=$('#path-svg'), R=rng(7);
  const IX=40,IY=30,IW=600,IH=340;
  const blobs=[[200,150,95],[430,240,75]];
  const abn=(x,y)=>blobs.some(([bx,by,br])=>Math.hypot(x-bx,y-by)<br);
  const cells=[]; for(let i=0;i<300;i++){ const x=R()*IW, y=R()*IH, r=6+R()*9; cells.push({x:IX+x,y:IY+y,r,a:abn(x,y),o:.35+R()*.45}); }
  const defs=h('defs',null,h('clipPath',{id:'imgclip'},h('rect',{x:IX,y:IY,width:IW,height:IH,rx:10})),h('clipPath',{id:'aiclip'},h('rect',{id:'airect',x:IX+IW/2,y:IY,width:IW/2,height:IH})));
  const base=h('g',{'clip-path':'url(#imgclip)'}), ai=h('g',{'clip-path':'url(#aiclip)'});
  base.append(h('rect',{x:IX,y:IY,width:IW,height:IH,fill:'#16337A',opacity:.5}));
  ai.append(h('rect',{x:IX,y:IY,width:IW,height:IH,fill:'#0B1F4B'}));
  cells.forEach(c=>{
    base.append(h('circle',{cx:c.x.toFixed(1),cy:c.y.toFixed(1),r:c.r.toFixed(1),fill:'var(--navy-lt)',opacity:c.o.toFixed(2)}),
                h('circle',{cx:c.x.toFixed(1),cy:c.y.toFixed(1),r:(c.r*.38).toFixed(1),fill:'var(--blue)',opacity:.85}));
    ai.append(h('circle',{cx:c.x.toFixed(1),cy:c.y.toFixed(1),r:c.r.toFixed(1),fill:c.a?'var(--red-lt)':'var(--green-lt)',opacity:c.a?.85:.45}));
  });
  blobs.forEach(([x,y,r])=>ai.append(h('circle',{cx:IX+x,cy:IY+y,r:r+10,fill:'none',stroke:'#fff','stroke-width':2,'stroke-dasharray':'6 5'})));
  const line=h('line',{y1:IY,y2:IY+IH,stroke:'#fff','stroke-width':3}), handle=h('circle',{cy:IY+IH/2,r:14,fill:'#fff',stroke:'var(--red-lt)','stroke-width':4});
  /* โมเลกุล */
  const MX=670, mol=h('g',{opacity:0});
  const N=[[70,70],[130,40],[190,80],[170,140],[100,150],[60,210],[140,230],[200,200]];
  const B=[[0,1],[1,2],[2,3],[3,4],[4,0],[4,5],[3,7],[5,6],[6,7]];
  mol.append(...B.map(([a,b])=>h('line',{x1:MX+N[a][0],y1:IY+60+N[a][1],x2:MX+N[b][0],y2:IY+60+N[b][1],stroke:'var(--navy-lt)','stroke-width':3})),
             ...N.map(([x,y],i)=>h('circle',{cx:MX+x,cy:IY+60+y,r:i%3===0?11:8,fill:i%3===0?'var(--red-lt)':(i%3===1?'var(--blue-lt)':'var(--green-lt)')})));
  svg.append(defs,base,ai,line,handle,
    h('rect',{x:MX-6,y:IY,width:216,height:IH,rx:10,fill:'rgba(255,255,255,.05)',stroke:'rgba(255,255,255,.2)'}),
    h('text',{class:'lg',x:MX+100,y:IY+30,'text-anchor':'middle'},'โครงสร้างโมเลกุล'),
    h('text',{class:'lg',x:MX+100,y:IY+IH-14,'text-anchor':'middle',style:{fontSize:'12px',fill:'#B7C4E4'}},'ที่ AI เชื่อมโยง (ภาพสมมติ)'),mol,
    h('text',{class:'lg',x:IX+8,y:IY+IH+22,style:{fontSize:'13px'}},'ภาพกล้องจุลทรรศน์จำลอง'),
    h('text',{class:'lg',x:IX+IW-8,y:IY+IH+22,'text-anchor':'end',style:{fontSize:'13px'}},'สิ่งที่ AI ทำนาย: เขียว = ปกติ · แดง = ผิดปกติ'));
  function set(v){
    const x=IX+IW*(1-v/100);
    $('#airect').setAttribute('x',x); $('#airect').setAttribute('width',IX+IW-x);
    line.setAttribute('x1',x); line.setAttribute('x2',x); handle.setAttribute('cx',x);
    mol.setAttribute('opacity',(v/100).toFixed(2));
  }
  $('#reveal').addEventListener('input',e=>set(+e.target.value)); set(50);
})();

/* =============== 3) เตือนโรคระบาด =============== */
(function(){
  const svg=$('#out-svg'), side=$('#oside'), R=rng(21);
  const COLS=7,ROWS=5,TOTAL=COLS*ROWS,DAYS=10,P=0.5;
  const farms=[]; for(let j=0;j<ROWS;j++) for(let i=0;i<COLS;i++) farms.push({x:75+i*92+(R()-.5)*34,y:60+j*76+(R()-.5)*30});
  const nb=farms.map((f,a)=>farms.map((g,b)=>b!==a&&Math.hypot(f.x-g.x,f.y-g.y)<125?b:-1).filter(b=>b>=0));
  const rn=Array.from({length:DAYS+1},()=>farms.map(()=>farms.map(()=>R())));
  const START=1*COLS+1;
  function sim(detect){
    const day=Array(TOTAL).fill(99); day[START]=0;
    for(let s=1;s<=DAYS;s++){
      if(s>detect) break;
      for(let f=0;f<TOTAL;f++) if(day[f]<s) nb[f].forEach(n=>{ if(day[n]===99&&rn[s][f][n]<P) day[n]=s; });
    }
    return day;
  }
  const SC={ none:{name:'ไม่มี AI เตือน',detect:6,col:'var(--red-lt)',day:null}, ai:{name:'มี AI เตือนล่วงหน้า',detect:2,col:'var(--green-lt)',day:null} };
  SC.none.day=sim(SC.none.detect); SC.ai.day=sim(SC.ai.detect);
  const cnt=(sc,t)=>SC[sc].day.filter(d=>d<=t).length;
  const lines=h('g'); const links=new Set();
  nb.forEach((arr,a)=>arr.forEach(b=>{ if(a<b) lines.append(h('line',{x1:farms[a].x,y1:farms[a].y,x2:farms[b].x,y2:farms[b].y,stroke:'rgba(255,255,255,.12)','stroke-width':1.5})); }));
  svg.append(lines);
  const els=farms.map((f,i)=>{ const c=h('circle',{class:'farm',cx:f.x.toFixed(1),cy:f.y.toFixed(1),r:11,fill:'#0B1F4B',stroke:'var(--navy-lt)','stroke-width':2.5}); svg.append(c); return c; });
  const pulse=h('circle',{cx:farms[START].x,cy:farms[START].y,r:26,fill:'none',stroke:'var(--green-lt)','stroke-width':3,opacity:0});
  const flag=h('text',{x:350,y:408,'text-anchor':'middle',style:{fontSize:'16px',fontWeight:700}},'');
  svg.append(pulse,flag);
  let sc='ai', t=0, timer=null;
  const bar=$('#oscen');
  Object.entries(SC).forEach(([k,v])=>bar.append(h('button',{type:'button','data-k':k,'aria-pressed':k===sc?'true':'false',onclick:()=>{ sc=k; $$('button',bar).forEach(b=>b.setAttribute('aria-pressed',b.dataset.k===k?'true':'false')); render(); }},v.name)));
  function render(){
    const S=SC[sc];
    farms.forEach((f,i)=>{
      const inf=S.day[i]<=t, contained=inf&&t>=S.detect;
      els[i].style.fill=inf?'var(--red-lt)':'#0B1F4B';
      els[i].style.stroke=contained?'var(--green-lt)':(inf?'var(--red-lt)':'var(--navy-lt)');
      els[i].setAttribute('r',inf?13:11);
    });
    const det=t>=S.detect;
    pulse.setAttribute('opacity',det?.9:0);
    flag.textContent=det?(sc==='ai'?'AI เตือนวันที่ '+S.detect+' และเริ่มควบคุม':'ตรวจพบวันที่ '+S.detect+' จึงเริ่มควบคุม'):'';
    flag.style.fill=sc==='ai'?'var(--green-lt)':'var(--red-lt)';
    $('#oday').textContent='วันที่ '+t; $('#ostep').value=t;
    side.innerHTML=''; side.style.setProperty('--accent',sc==='ai'?'var(--green)':'var(--red)');
    side.append(h('h3',null,S.name),h('p',{class:'muted small'},'ตรวจพบและเริ่มควบคุมวันที่ '+S.detect),
      h('div',{class:'num'},String(cnt(sc,t)),h('small',null,'ฟาร์มติดเชื้อ จากทั้งหมด '+TOTAL)),
      h('h4',null,'เมื่อจบวันที่ '+DAYS+' ในสถานการณ์จำลองนี้'),
      h('div',{class:'row'},h('span',null,'ไม่มี AI เตือน'),h('b',null,cnt('none',DAYS)+' ฟาร์ม')),
      h('div',{class:'row'},h('span',null,'มี AI เตือนล่วงหน้า'),h('b',null,cnt('ai',DAYS)+' ฟาร์ม')),
      h('p',{class:'small muted',style:{marginTop:'10px'}},'เตือนเร็วขึ้น ควบคุมเร็วขึ้น โรคจึงไปได้ไม่กี่ฟาร์ม สีเขียวที่ขอบคือฟาร์มที่อยู่ในการควบคุมแล้ว'));
  }
  $('#ostep').addEventListener('input',e=>{ stop(); t=+e.target.value; render(); });
  function stop(){ clearInterval(timer); timer=null; $('#oplay').textContent='เล่น'; }
  $('#oplay').addEventListener('click',()=>{
    if(timer){ stop(); return; }
    if(reduce){ t=DAYS; render(); return; }
    if(t>=DAYS) t=0; $('#oplay').textContent='หยุด'; render();
    timer=setInterval(()=>{ if(t>=DAYS){ stop(); return; } t++; render(); },750);
  });
  render();
})();

/* =============== 4) ไมโครไบโอม =============== */
(function(){
  const svg=$('#mic-svg'), R=rng(5);
  const JX=395,JY=80,JW=150,JH=260;
  /* วัว */
  const cow=h('g',{transform:'translate(30 40)'},
    h('ellipse',{cx:130,cy:210,rx:82,ry:44,fill:'#0B1F4B',stroke:'var(--navy-lt)','stroke-width':2.5}),
    h('ellipse',{cx:226,cy:186,rx:34,ry:26,fill:'#0B1F4B',stroke:'var(--navy-lt)','stroke-width':2.5}),
    ...[70,100,160,190].map(x=>h('rect',{x:x-7,y:240,width:14,height:54,rx:4,fill:'#0B1F4B',stroke:'var(--navy-lt)','stroke-width':2})),
    h('path',{d:'M48 200 C26 210 24 240 30 262',fill:'none',stroke:'var(--navy-lt)','stroke-width':3}),
    h('circle',{cx:108,cy:200,r:9,fill:'var(--navy-lt)',opacity:.5}),h('circle',{cx:150,cy:222,r:12,fill:'var(--navy-lt)',opacity:.5}),
    h('circle',{cx:234,cy:180,r:4,fill:'#fff'}));
  const PUFFS=Array.from({length:9},(_,i)=>({x:120+R()*40,y:150-R()*30,p:i/9,r:9+R()*8}));
  const puffEls=PUFFS.map(()=>h('circle',{fill:'#B7C4E4',opacity:0}));
  /* ขวด */
  const liquid=h('rect',{x:JX+6,y:JY+70,width:JW-12,height:JH-76,rx:12,fill:'var(--green-lt)',opacity:.22});
  const jar=h('rect',{x:JX,y:JY,width:JW,height:JH,rx:20,fill:'none',stroke:'var(--navy-lt)','stroke-width':3.5});
  const clipJar=h('clipPath',{id:'jarclip'},h('rect',{x:JX+6,y:JY+70,width:JW-12,height:JH-76,rx:12}));
  const MIC=Array.from({length:34},()=>({x:JX+20+R()*(JW-40),y:JY+90+R()*(JH-110),vx:(R()-.5)*18,vy:(R()-.5)*18,r:4+R()*3}));
  const micEls=MIC.map(()=>h('circle',{}));
  const BUB=Array.from({length:16},(_,i)=>({x:JX+24+R()*(JW-48),y:JY+JH-20-R()*(JH-100),s:18+R()*26,r:2.5+R()*3.5}));
  const bubEls=BUB.map(()=>h('circle',{fill:'#fff'}));
  const g=h('g',{'clip-path':'url(#jarclip)'},...micEls,...bubEls);
  /* มาตรวัด */
  const MET=[
    {n:'ประสิทธิภาพการใช้อาหาร',dir:'สูงขึ้น',col:'var(--green-lt)',f:v=>30+60*v},
    {n:'การพึ่งพายาปฏิชีวนะ',dir:'ลดลง',col:'var(--red-lt)',f:v=>85-60*v},
    {n:'มีเทนจากสัตว์เคี้ยวเอื้อง',dir:'ลดลง',col:'var(--red-lt)',f:v=>88-65*v}
  ];
  const mx=640, mw=220;
  const mets=MET.map((m,i)=>{
    const y=120+i*92;
    const track=h('rect',{x:mx,y:y+22,width:mw,height:16,rx:8,fill:'rgba(255,255,255,.14)'});
    const fill=h('rect',{x:mx,y:y+22,height:16,rx:8,fill:m.col});
    const st=h('text',{class:'ms',x:mx+mw,y:y+60,'text-anchor':'end'},'');
    svg.append(h('text',{class:'mt',x:mx,y:y+12},m.n),track,fill,st);
    return {m,fill,st};
  });
  svg.append(h('defs',null,clipJar),cow,...puffEls,liquid,jar,g,
    h('text',{class:'mt',x:JX+JW/2,y:JY-18,'text-anchor':'middle'},'โรงงานจุลินทรีย์ในท้องสัตว์'),
    h('text',{class:'ms',x:130,y:372,'text-anchor':'middle'},'วัวปล่อยมีเทนจากการย่อยอาหาร'),
    h('text',{class:'mt',x:mx,y:84},'ผลที่ตามมา'),
    h('text',{class:'ms',x:JX+JW/2,y:JY+JH+28,'text-anchor':'middle'},'ตัวอย่างต้นแบบของอาหารที่ปรับตามจุลินทรีย์'));
  let v=0;
  function paint(){
    const mix=`color-mix(in srgb, var(--green-lt) ${Math.round(v*100)}%, var(--navy-lt))`;
    micEls.forEach(m=>m.style.fill=mix);
    liquid.setAttribute('opacity',(.18+.3*v).toFixed(2));
    mets.forEach(({m,fill,st})=>{ fill.setAttribute('width',(mw*m.f(v)/100).toFixed(1)); st.textContent=(m.dir==='สูงขึ้น'?'▲ ':'▼ ')+m.dir+(v>0.02?'':' (ยังไม่เปลี่ยน)'); });
  }
  function frame(dt,t){
    MIC.forEach((m,i)=>{
      m.x+=m.vx*dt; m.y+=m.vy*dt;
      if(m.x<JX+16||m.x>JX+JW-16) m.vx*=-1; if(m.y<JY+86||m.y>JY+JH-14) m.vy*=-1;
      micEls[i].setAttribute('cx',m.x.toFixed(1)); micEls[i].setAttribute('cy',m.y.toFixed(1)); micEls[i].setAttribute('r',m.r.toFixed(1));
    });
    BUB.forEach((b,i)=>{
      b.y-=b.s*(0.4+v*1.6)*dt; if(b.y<JY+74){ b.y=JY+JH-14; b.x=JX+24+R()*(JW-48); }
      bubEls[i].setAttribute('cx',(b.x+Math.sin(t*2+i)*4).toFixed(1)); bubEls[i].setAttribute('cy',b.y.toFixed(1)); bubEls[i].setAttribute('r',b.r.toFixed(1));
      bubEls[i].setAttribute('opacity',(i/BUB.length<.3+v*.7?.7:0).toFixed(2));
    });
    const show=Math.round(PUFFS.length*(1-.8*v));
    PUFFS.forEach((p,i)=>{
      p.p=(p.p+dt*0.16)%1; const e=puffEls[i];
      e.setAttribute('cx',(p.x+Math.sin(t+i)*8+p.p*30).toFixed(1)); e.setAttribute('cy',(p.y+40-p.p*130).toFixed(1));
      e.setAttribute('r',(p.r*(0.6+p.p)).toFixed(1)); e.setAttribute('opacity',i<show?(0.55*(1-p.p)).toFixed(2):0);
    });
  }
  $('#feed').addEventListener('input',e=>{ v=e.target.value/100; paint(); if(reduce) frame(0,0); });
  paint();
  whenVisible(svg,frame);
})();
Terms.enhance(document);
})();
