(function(){
const {h,$,$$}=Core; const V=VF;
const list=$('#glist'), q=$('#q'); let cat='all';
const rows=V.glossary.map(g=>{
  const el=h('div',{class:'g',id:g.k},h('h3',null,g.t,h('small',null,V.catNames[g.c])),h('div',null,h('p',null,g.p),h('p',{class:'like'},'เปรียบเหมือน: '+g.a)));
  list.append(el); return {g,el};
});
function apply(){
  const s=q.value.trim().toLowerCase(); let n=0;
  rows.forEach(({g,el})=>{
    const hay=(g.t+' '+g.p+' '+g.a+' '+V.catNames[g.c]).toLowerCase();
    const ok=(cat==='all'||g.c===cat)&&(!s||hay.includes(s)); el.hidden=!ok; if(ok) n++;
  });
  $('#gcount').textContent='แสดง '+n+' จาก '+rows.length+' คำ';
}
const bar=$('#cats');
[['all','ทั้งหมด'],...Object.entries(V.catNames)].forEach(([k,n])=>bar.append(h('button',{type:'button','data-k':k,'aria-pressed':k==='all'?'true':'false',onclick:()=>{ cat=k; $$('button',bar).forEach(b=>b.setAttribute('aria-pressed',b.dataset.k===k?'true':'false')); apply(); }},n)));
q.addEventListener('input',apply); apply();
if(location.hash){ const t=document.getElementById(decodeURIComponent(location.hash.slice(1))); if(t){ t.classList.add('flash'); setTimeout(()=>t.scrollIntoView({block:'center'}),150); setTimeout(()=>t.classList.remove('flash'),2600); } }
})();
