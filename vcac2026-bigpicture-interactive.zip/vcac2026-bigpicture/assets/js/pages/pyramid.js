(function(){
const {h,$,$$,Flow,tween,lerp,reduce}=Core;
const V=VF, T=Terms.T;
const pyr=$('#pyr'), rad=$('#radar'), side=$('#lvl'), note=$('#pyrnote');

/* ---------- pyramid ---------- */
const xl=y=>300-260*(y-34)/370;
const RANGE=[[286,404],[160,278],[34,152]];
const SHORT=['มาตรฐานสากล','AI และวิจัย','ผู้นำ'];
let lvl=0, mode='ceil';
const layers=V.levels.map((L,i)=>{
  const [y0,y1]=RANGE[i];
  const pts=[[xl(y0),y0],[600-xl(y0),y0],[600-xl(y1),y1],[xl(y1),y1]].map(p=>p.map(n=>n.toFixed(1)).join(',')).join(' ');
  const mid=(y0+y1)/2+(i===2?16:0);
  const g=h('g',{class:'layer',tabindex:0,role:'button','aria-label':'ระดับ '+L.id+' '+L.name},
    h('polygon',{points:pts}),
    h('text',{class:'t1','text-anchor':'middle',x:300,y:mid-2},'ระดับ '+L.id),
    h('text',{class:'t2','text-anchor':'middle',x:300,y:mid+20},SHORT[i]));
  g.addEventListener('click',()=>setLvl(i));
  g.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); setLvl(i); } });
  pyr.append(g); return g;
});
const ceil=h('g',{class:'ceil'},h('rect',{x:24,y:262,width:552,height:26,rx:3}),h('text',{x:300,y:281},'เพดาน: ผ่านเกณฑ์ขั้นต่ำแล้วจบ'));
pyr.append(ceil);
const tok=h('g',{transform:'translate(70 392)'},h('circle',{class:'tok',r:13}),h('text',{class:'tk',y:-22},'ผู้เรียน'));
pyr.append(tok);

function setMode(m){
  mode=m;
  $$('#mode button').forEach(b=>b.setAttribute('aria-pressed',b.dataset.m===m?'true':'false'));
  ceil.classList.toggle('up',m==='base');
  layers[1].classList.toggle('locked',m==='ceil'); layers[2].classList.toggle('locked',m==='ceil');
  note.textContent= m==='ceil'
    ? 'เมื่อมองมาตรฐานเป็นเพดาน เป้าหมายคือผ่านเกณฑ์ขั้นต่ำแล้วหยุด ระดับ 2 และ 3 จึงไม่มีเส้นทางให้ไป'
    : 'เมื่อมองมาตรฐานเป็นฐาน ทุกคนต้องผ่านระดับ 1 แต่คนที่อยากไปต่อมีเส้นทางสู่ระดับ 2 และ 3';
  moveTok(70,392);
}
function moveTok(x,y){ tok.setAttribute('transform',`translate(${x} ${y})`); }
let cver=0;
function climb(){
  const my=++cver;
  const wp= mode==='base' ? [[70,392],[300,348],[300,220],[300,56]] : [[70,392],[300,348],[300,322],[300,348],[300,322],[300,348]];
  const segs=wp.length-1;
  tween(reduce?1:2600,e=>{
    if(my!==cver) return;
    const f=e*segs, i=Math.min(segs-1,Math.floor(f)), t=f-i;
    moveTok(lerp(wp[i][0],wp[i+1][0],t),lerp(wp[i][1],wp[i+1][1],t));
  },()=>{
    if(my!==cver) return;
    if(mode==='base'){ setLvl(2); note.textContent='ถึงระดับ 3 แล้ว มาตรฐานสากลคือจุดเริ่มต้นของการปีน ไม่ใช่เส้นชัย'; }
    else note.textContent='ติดเพดาน ผู้เรียนผ่านเกณฑ์ระดับ 1 แล้วแต่ไม่มีทางไปต่อ ลองสลับเป็น "ฐาน" แล้วปีนใหม่';
  });
}
$('#mode').addEventListener('click',e=>{ const b=e.target.closest('button'); if(b) setMode(b.dataset.m); });
$('#climb').addEventListener('click',climb);

/* ---------- radar ---------- */
const RC={x:260,y:210}, RR=118, NA=6;
const ang=i=>(-90+360/NA*i)*Math.PI/180;
const pt=(i,r)=>[RC.x+r*Math.cos(ang(i)),RC.y+r*Math.sin(ang(i))];
const poly=a=>a.map((s,i)=>pt(i,RR*s/5).map(n=>n.toFixed(1)).join(',')).join(' ');
for(let k=1;k<=5;k++) rad.append(h('polygon',{class:'ring',points:poly(Array(NA).fill(k))}));
V.radarAxes.forEach((a,i)=>{
  const [x2,y2]=pt(i,RR); rad.append(h('line',{class:'axis',x1:RC.x,y1:RC.y,x2:x2.toFixed(1),y2:y2.toFixed(1)}));
  const [lx,ly]=pt(i,RR+20), c=Math.cos(ang(i)), s=Math.sin(ang(i));
  rad.append(h('text',{class:'al','text-anchor':c>0.3?'start':(c<-0.3?'end':'middle'),x:lx.toFixed(1),y:(ly+(s<-0.8?-6:(s>0.8?14:5))).toFixed(1)},a));
});
const g1=h('polygon',{fill:'none',stroke:'rgba(255,255,255,.35)','stroke-width':1.5,'stroke-dasharray':'4 4'});
const g2=h('polygon',{fill:'none',stroke:'rgba(255,255,255,.35)','stroke-width':1.5,'stroke-dasharray':'4 4'});
const shape=h('polygon',{fill:'rgba(134,161,245,.38)',stroke:'var(--blue-lt)','stroke-width':2.6,'stroke-linejoin':'round'});
const dots=Array.from({length:NA},()=>h('circle',{r:4.5,fill:'#fff',stroke:'var(--blue-lt)','stroke-width':2}));
rad.append(g1,g2,shape,...dots);
let cv=V.levels[0].radar.slice();
function drawRadar(){ shape.setAttribute('points',poly(cv)); dots.forEach((d,i)=>{ const [x,y]=pt(i,RR*cv[i]/5); d.setAttribute('cx',x.toFixed(1)); d.setAttribute('cy',y.toFixed(1)); }); }
drawRadar();

function setLvl(i){
  lvl=i;
  layers.forEach((g,k)=>g.classList.toggle('sel',k===i));
  g1.setAttribute('points',i>=1?poly(V.levels[0].radar):''); g2.setAttribute('points',i>=2?poly(V.levels[1].radar):'');
  const from=cv.slice(), to=V.levels[i].radar;
  tween(650,e=>{ cv=from.map((v,k)=>lerp(v,to[k],e)); drawRadar(); });
  const L=V.levels[i];
  side.innerHTML=''; side.style.setProperty('--accent','var(--blue)');
  side.append(h('span',{class:'lv-id'},'ระดับ '+L.id),h('h3',null,L.name),h('p',{class:'muted small'},L.th+' · '+L.who),
    h('p',null,L.plain),h('div',{class:'like-box'},h('b',null,'เปรียบเหมือน '),L.like.replace(/^เหมือน/,'')),
    h('h4',null,'ทำอะไรได้'),h('ul',null,L.can.map(x=>h('li',null,x))),
    h('h4',null,'เรียนรู้ผ่านอะไร'),h('ul',null,L.by.map(x=>h('li',null,x))));
  side.classList.remove('swap'); void side.offsetWidth; side.classList.add('swap');
}
setMode('ceil'); setLvl(0);

/* ---------- One strategy ---------- */
const os=$('#one'), oside=$('#oneside');
const NODES=[[190,80],[710,80],[190,380],[710,380]];
const LINES=[['One Competency','Framework'],['One Evidence-Based','Assessment'],['One Lifelong','Learning Pathway'],['One Research &','Innovation Ecosystem']];
const lineL=h('g'), dotL=h('g',{'pointer-events':'none'}), nodeL=h('g');
os.append(lineL,dotL,nodeL);
const C={x:450,y:230};
NODES.forEach(([x,y])=>{
  const sx=x<C.x?-1:1, sy=y<C.y?-1:1;
  const p=h('path',{class:'sp',d:`M ${C.x+sx*76} ${C.y+sy*30} C ${C.x+sx*150} ${C.y+sy*30}, ${x-sx*140} ${y+(sy<0?37:-37)}, ${x-sx*70} ${y+(sy<0?37:-37)}`});
  lineL.append(p); Flow.add(p,{n:3,r:3,speed:55,color:'var(--navy-lt)',layer:dotL});
});
nodeL.append(h('g',{class:'core'},h('circle',{cx:C.x,cy:C.y,r:78}),h('text',{x:C.x,y:C.y-8},'ตกลงร่วมกัน'),h('text',{class:'sb',x:C.x,y:C.y+14},'อว. · สภา · มหาวิทยาลัย')));
let osel=0; const opEls=[];
NODES.forEach(([x,y],i)=>{
  const g=h('g',{class:'op',tabindex:0,role:'button','aria-label':V.oneStrategy[i].n},
    h('rect',{x:x-138,y:y-38,width:276,height:76,rx:12}),
    h('text',{'text-anchor':'middle',x,y:y-4},LINES[i][0]),
    h('text',{'text-anchor':'middle',x,y:y+20},LINES[i][1]));
  g.addEventListener('click',()=>pickOne(i)); g.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); pickOne(i); } });
  nodeL.append(g); opEls.push(g);
});
function pickOne(i){
  osel=i; opEls.forEach((g,k)=>g.classList.toggle('sel',k===i));
  const s=V.oneStrategy[i]; oside.innerHTML=''; oside.style.setProperty('--accent','var(--red)');
  oside.append(h('h3',null,s.n),h('p',null,s.plain),h('h4',null,'ใครต้องตกลงกัน'),h('p',null,s.who),
    h('div',{class:'like-box'},h('b',null,'เปรียบเหมือน '),s.like.replace(/^เหมือน/,'')));
  oside.classList.remove('swap'); void oside.offsetWidth; oside.classList.add('swap');
}
pickOne(0);
Terms.enhance(document);
})();
