(function(){
const {h,$,$$,Flow}=Core;
const V=VF, T=Terms.T;

/* =============== 1) One Health triangle =============== */
const svg=$('#oh'), side=$('#ohside');
const POS={animal:{x:450,y:118,r:70},human:{x:170,y:400,r:70},env:{x:730,y:400,r:70}};
const PAIRS=[['animal','human'],['animal','env'],['human','env']];
const edgeLayer=h('g'), dotLayer=h('g',{'pointer-events':'none'}), nodeLayer=h('g');
svg.append(edgeLayer,dotLayer,nodeLayer);

function lane(a,b,off){
  const A=POS[a],B=POS[b], dx=B.x-A.x, dy=B.y-A.y, L=Math.hypot(dx,dy), ux=dx/L, uy=dy/L, nx=-uy, ny=ux;
  const x0=A.x+ux*(A.r+8)+nx*off, y0=A.y+uy*(A.r+8)+ny*off, x1=B.x-ux*(B.r+8)+nx*off, y1=B.y-uy*(B.r+8)+ny*off;
  return `M ${x0.toFixed(1)} ${y0.toFixed(1)} L ${x1.toFixed(1)} ${y1.toFixed(1)}`;
}
const edges=PAIRS.map(([a,b])=>{
  const fwd=h('path',{class:'edge',d:lane(a,b,7)}), back=h('path',{class:'edge',d:lane(b,a,7)});
  edgeLayer.append(fwd,back);
  const f1=Flow.add(fwd,{n:3,r:3.2,speed:55,color:'var(--navy-lt)',layer:dotLayer});
  const f2=Flow.add(back,{n:3,r:3.2,speed:55,color:'var(--navy-lt)',layer:dotLayer});
  return {a,b,els:[fwd,back],flows:[f1,f2]};
});
const nodes={};
Object.entries(POS).forEach(([id,p])=>{
  const d=V.oneHealthNodes[id];
  const g=h('g',{class:'nd',tabindex:0,role:'img','aria-label':d.name},
    h('circle',{class:'b',cx:p.x,cy:p.y,r:p.r}),
    h('text',{class:'nm','text-anchor':'middle',x:p.x,y:p.y+8},d.name),
    h('text',{class:'sb','text-anchor':'middle',x:p.x,y:p.y+p.r+22},d.sub));
  nodeLayer.append(g); nodes[id]=g;
});
nodeLayer.append(h('g',{class:'hub'},h('circle',{cx:450,cy:315,r:46}),h('text',{x:450,y:312},'สุขภาพ'),h('text',{x:450,y:332},'หนึ่งเดียว')));
const mark=h('g',{class:'mark',opacity:0});
nodeLayer.append(mark);

let sel=null;
function placeMark(p){
  mark.innerHTML='';
  const ns=p.nodes;
  let mx,my,ly;
  if(ns.length===3){ mx=450; my=315; ly=388; mark.append(h('circle',{class:'pulse',cx:mx,cy:my,r:46})); }
  else { const A=POS[ns[0]],B=POS[ns[1]]; mx=(A.x+B.x)/2; my=(A.y+B.y)/2; ly=my+34; mark.append(h('circle',{class:'pulse',cx:mx,cy:my,r:13}),h('circle',{class:'m',cx:mx,cy:my,r:13})); }
  mark.append(h('text',{x:mx,y:ly},p.name));
}
function apply(){
  const p=V.problems.find(x=>x.id===sel);
  Object.entries(nodes).forEach(([id,g])=>{ g.classList.toggle('on',!!p&&p.nodes.includes(id)); g.classList.toggle('off',!!p&&!p.nodes.includes(id)); });
  edges.forEach(e=>{
    const on=!!p&&p.nodes.includes(e.a)&&p.nodes.includes(e.b);
    e.els.forEach(el=>{ el.classList.toggle('on',on); el.classList.toggle('off',!!p&&!on); });
    e.flows.forEach(f=>f.setActive(!p||on));
  });
  if(p){ placeMark(p); mark.setAttribute('opacity',1); } else mark.setAttribute('opacity',0);
  renderSide(p);
  $$('#probs button').forEach(b=>b.setAttribute('aria-pressed',b.dataset.id===(sel||'none')?'true':'false'));
}
function renderSide(p){
  side.innerHTML=''; side.style.setProperty('--accent','var(--green)');
  if(!p){
    side.append(h('h3',null,T('onehealth','One Health')),
      h('p',null,'คน สัตว์ และสิ่งแวดล้อมใช้ชีวิตร่วมกันและส่งผลถึงกัน โรคจึงข้ามไปมาได้ อาหารมาจากสัตว์ และสิ่งแวดล้อมก็เปลี่ยนไปตามสิ่งที่เรากินและใช้'),
      h('div',{class:'like-box'},h('b',null,'เปรียบเหมือน '),'บ้านหลังเดียวที่ครัว ห้องนอน และสวนใช้ท่อน้ำเส้นเดียวกัน ท่อรั่วที่หนึ่ง ที่อื่นก็เปียก'),
      h('p',{class:'muted'},'เลือกปัญหาด้านบนเพื่อดูว่าเกี่ยวข้องกับใครบ้าง'));
    Terms.enhance(side); return;
  }
  side.append(h('h3',null,p.name),
    h('div',{class:'tg'},p.nodes.map(n=>h('span',{class:'tag trust'},V.oneHealthNodes[n].name))),
    h('h4',null,'เข้าใจง่ายๆ'),h('p',null,p.plain),
    h('h4',null,'สัตวแพทย์ช่วยอะไร'),h('p',null,p.vet),
    h('p',null,h('a',{href:p.link},'ดูต่อ')));
  side.classList.remove('swap'); void side.offsetWidth; side.classList.add('swap');
}
const bar=$('#probs');
bar.append(h('button',{type:'button','data-id':'none','aria-pressed':'true',onclick:()=>{ sel=null; apply(); }},'ภาพรวม'));
V.problems.forEach(p=>bar.append(h('button',{type:'button','data-id':p.id,'aria-pressed':'false',onclick:()=>{ sel=p.id; apply(); }},p.name)));
apply();

/* =============== 2) economic ecosystem =============== */
const es=$('#eco'), eside=$('#ecoside');
const FL=[['medica',170,'--blue-lt'],['terra',450,'--green-lt'],['silica',730,'--navy-lt']];
const L2=h('g'), D2=h('g',{'pointer-events':'none'}), N2=h('g');
es.append(L2,D2,N2);
function addLine(d,col,n,sp){ const p=h('path',{class:'line',d,style:{stroke:'var('+col+')'}}); L2.append(p); Flow.add(p,{n:n||3,r:3,speed:sp||60,color:'var('+col+')',layer:D2}); }
FL.forEach(([id,x,col])=>addLine(`M ${x} 150 C ${x} 215, 450 205, 450 262`,col,3,58));
addLine('M 450 346 L 450 424','--red-lt',4,60);
const flEls={};
FL.forEach(([id,x,col])=>{
  const f=V.flagships[id];
  const g=h('g',{class:'fl',tabindex:0,role:'button','aria-label':f.name},
    h('rect',{x:x-118,y:60,width:236,height:90,rx:12,style:{stroke:'var('+col+')'}}),
    h('text',{class:'nm','text-anchor':'middle',x,y:98},f.name),
    h('text',{class:'sb','text-anchor':'middle',x,y:124},f.tag));
  g.addEventListener('click',()=>pick(id)); g.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); pick(id); } });
  N2.append(g); flEls[id]=g;
});
N2.append(h('g',{class:'box'},
  h('rect',{x:215,y:262,width:470,height:84,rx:12,style:{stroke:'var(--red-lt)'}}),
  h('text',{class:'nm',x:450,y:300},'Veterinary Discovery'),
  h('text',{class:'sb',x:450,y:326},'AI + One Health + มาตรฐานสากล')),
  h('g',{class:'box'},
  h('rect',{x:215,y:424,width:470,height:76,rx:12,style:{stroke:'var(--red-lt)'}}),
  h('text',{class:'nm',x:450,y:458},'New Growth Engines'),
  h('text',{class:'sb',x:450,y:482},'เครื่องยนต์เศรษฐกิจใหม่ · อุตสาหกรรมมูลค่าสูง')));
let fsel=null;
function pick(id){
  fsel=fsel===id?null:id;
  Object.entries(flEls).forEach(([k,g])=>g.classList.toggle('sel',k===fsel));
  eside.innerHTML=''; 
  if(!fsel){ eside.style.setProperty('--accent','var(--navy)');
    eside.append(h('h3',null,'คลิกธงเพื่อดูข้างใน'),h('p',{class:'muted'},'สามธงของกระทรวง อว. คือ Siam Medica, Siam Terra และ Siam Silica ทั้งสามไหลมารวมที่ "การค้นพบทางสัตวแพทย์" แล้วกลายเป็นเศรษฐกิจใหม่'));
    return; }
  const f=V.flagships[fsel];
  eside.style.setProperty('--accent','var(--'+f.col+')');
  eside.append(h('h3',null,f.name),h('p',{class:'muted small'},f.tag),h('p',null,f.plain),
    h('h4',null,'งานที่สัตวแพทย์พัฒนา'),h('ul',null,f.does.map(x=>h('li',null,x))),
    h('h4',null,'ผลลัพธ์ทางเศรษฐกิจ'),h('div',null,f.outs.map(x=>h('span',{class:'tag line'},x))));
  eside.classList.remove('swap'); void eside.offsetWidth; eside.classList.add('swap');
}
pick(null);

/* =============== 3) pillars =============== */
const NEAR=new Set(['Drug and Vaccine Development / Tropical Medicine','Synthetic Biology','Biotechnology','Medical Device','Clinical Trial Hub','Medical AI Hub','ATMPs / Precision Medicine','Cell & Gene Therapy / Tissue Engineering']);
const PIL={
  agri:{n:'เกษตรมูลค่าสูง',l:[['Herbal Innovation','นวัตกรรมสมุนไพร'],['Cosmeceuticals','เวชสำอาง'],['Medical Food','อาหารทางการแพทย์']]},
  ind:{n:'อุตสาหกรรมมูลค่าสูง',l:[['Semiconductor','เซมิคอนดักเตอร์'],['Medical Device','เครื่องมือแพทย์'],['Cell & Gene Therapy / Tissue Engineering','การรักษาด้วยเซลล์ ยีน และวิศวกรรมเนื้อเยื่อ'],['Drug and Vaccine Development / Tropical Medicine','พัฒนายาและวัคซีน / เวชศาสตร์เขตร้อน'],['Biotechnology','เทคโนโลยีชีวภาพ'],['Synthetic Biology','ชีววิทยาสังเคราะห์'],['Green Premium Tech','เทคโนโลยีสีเขียวระดับพรีเมียม'],['Space Economy','เศรษฐกิจอวกาศ'],['Defense Industry','อุตสาหกรรมป้องกันประเทศ']]},
  svc:{n:'บริการมูลค่าสูง',l:[['Wellness Tourism / Economy','ท่องเที่ยวและเศรษฐกิจสุขภาวะ'],['Medical Tourism / Telemedicine','ท่องเที่ยวเชิงการแพทย์ / แพทย์ทางไกล'],['ATMPs / Precision Medicine','การรักษาขั้นสูง / การแพทย์แม่นยำ'],['Clinical Trial Hub','ศูนย์กลางทดลองยาในคน'],['Creative Economy Hub (Soft Power)','เศรษฐกิจสร้างสรรค์ (Soft Power)'],['Fin Tech Hub / IPO Hub','ศูนย์กลางการเงินและการระดมทุน'],['Medical AI Hub','ศูนย์กลาง AI ทางการแพทย์']]}
};
const pb=$('#pillar'), il=$('#inds');
function showPillar(k){
  $$('button',pb).forEach(b=>b.setAttribute('aria-pressed',b.dataset.k===k?'true':'false'));
  il.innerHTML='';
  PIL[k].l.forEach(([en,th])=>il.append(h('li',{class:NEAR.has(en)?'near':null},th,h('small',null,en+(NEAR.has(en)?' · ใกล้งานสัตวแพทย์':'')))));
}
Object.entries(PIL).forEach(([k,v])=>pb.append(h('button',{type:'button','data-k':k,'aria-pressed':'false',onclick:()=>showPillar(k)},v.n)));
showPillar('ind');
Terms.enhance(document);
})();
