(function(){
const {h,$,$$,reduce}=Core;
const V=VF, N=V.pieces.length;
const TONE={policy:'red',capital:'red',medica:'blue',terra:'green',silica:'navy',data:'navy',platform:'navy',standard:'navy',l1:'blue',l2:'blue',l3:'blue'};
const board=$('#board'), tray=$('#tray'), info=$('#info'), roof=$('#roof');
const P={}; V.pieces.forEach(p=>P[p.id]=p);
const placed={}; let selected=null, mistakes=0, solving=false, drag=null;

/* ---------- build ---------- */
function slotInner(s){ return [h('div',{class:'zone'},s.zone),h('div',{class:'clue'},s.clue)]; }
const slotEls={};
V.slots.forEach(s=>{
  const el=h('div',{class:'slot',tabindex:0,role:'button','data-id':s.id,'aria-label':'ช่อง: '+s.clue,style:{gridColumn:s.col,gridRow:s.row+' / span '+s.span}},slotInner(s));
  el.addEventListener('click',()=>onSlot(el)); el.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); onSlot(el); } });
  board.append(el); slotEls[s.id]=el;
});
const pieceEls={};
V.pieces.forEach(p=>{
  const el=h('div',{class:'piece tr-'+TONE[p.id],tabindex:0,role:'button','data-id':p.id,'aria-label':'ชิ้นส่วน '+p.t},h('b',null,p.t),h('span',null,p.s));
  el.addEventListener('pointerdown',e=>down(e,el));
  el.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); select(el); } });
  pieceEls[p.id]=el;
});
function shuffleTray(){
  const ids=V.pieces.map(p=>p.id).filter(id=>!placed[id]);
  for(let i=ids.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [ids[i],ids[j]]=[ids[j],ids[i]]; }
  tray.innerHTML=''; ids.forEach(id=>tray.append(pieceEls[id]));
}

/* ---------- info panel ---------- */
function intro(){
  info.innerHTML=''; info.style.setProperty('--accent','var(--red)');
  info.append(h('h3',null,'วิธีเล่น'),
    h('ol',null,h('li',null,'อ่านคำใบ้ในช่องว่าง เช่น "ฐานที่ทุกคนต้องมี?"'),h('li',null,'ลากชิ้นส่วนจากด้านล่างไปวาง หรือแตะชิ้นส่วนแล้วแตะช่อง'),h('li',null,'ถ้าตัน กด "ขอใบ้" หรือ "ต่อให้ดู"')),
    h('p',{class:'muted small'},'แตะชิ้นส่วนเพื่ออ่านคำอธิบายง่ายๆ ก่อนตัดสินใจวาง'));
}
function showPiece(id,note){
  const p=P[id]; info.innerHTML=''; info.style.setProperty('--accent','var(--'+TONE[id]+')');
  info.append(h('h3',null,p.t),h('p',{class:'muted small'},p.s),h('p',null,p.e),
    h('div',{class:'like-box'},h('b',null,'เปรียบเหมือน '),p.like.replace(/^เหมือน/,'')),
    note?h('div',{class:'callout red'},note):null,
    placed[id]?h('p',null,h('a',{href:p.page},'อ่านเรื่องนี้เพิ่ม')):null);
  info.classList.remove('swap'); void info.offsetWidth; info.classList.add('swap');
}

/* ---------- selection ---------- */
function select(el){
  if(selected) selected.classList.remove('sel');
  if(selected===el){ selected=null; intro(); return; }
  selected=el; el.classList.add('sel'); showPiece(el.dataset.id);
}
function onSlot(slot){
  if(solving) return;
  if(slot.classList.contains('filled')){ showPiece(slot.dataset.id); return; }
  if(selected){ attempt(selected,slot); return; }
  const s=V.slots.find(x=>x.id===slot.dataset.id);
  info.innerHTML=''; info.append(h('h3',null,'ช่องนี้ถามว่า'),h('p',{class:'big'},s.clue),h('p',{class:'muted'},'โซน: '+s.zone+' · เลือกชิ้นส่วนก่อน แล้วแตะช่องนี้อีกครั้ง'));
}

/* ---------- place / attempt ---------- */
function attempt(piece,slot,fromDrag){
  if(piece.dataset.id===slot.dataset.id){ place(piece,slot); return true; }
  mistakes++;
  slot.classList.remove('shake'); void slot.offsetWidth; slot.classList.add('shake');
  showPiece(piece.dataset.id,'ยังไม่ใช่ช่องนี้ ลองอ่านคำใบ้ในช่องอีกครั้ง หรือกด "ขอใบ้"');
  if(fromDrag) giveBack(piece);
  return false;
}
function place(piece,slot){
  const id=piece.dataset.id;
  if(drag&&drag.ph){ drag.ph.remove(); }
  piece.classList.remove('drag','sel'); piece.style.cssText='';
  piece.classList.add('placed','pop'); slot.classList.remove('target','over'); slot.classList.add('filled');
  slot.innerHTML=''; slot.append(piece); placed[id]=true;
  if(selected===piece) selected=null;
  showPiece(id); progress();
  if(Object.keys(placed).length===N) complete();
}
function progress(){
  const n=Object.keys(placed).length; $('#pc').textContent=n; $('#pb').style.width=(n/N*100)+'%';
}

/* ---------- drag ---------- */
function down(e,el){
  if(solving||el.classList.contains('placed')||(e.button&&e.button!==0)) return;
  drag={el,sx:e.clientX,sy:e.clientY,moved:false,id:e.pointerId,ph:null,ox:0,oy:0};
  try{ el.setPointerCapture(e.pointerId); }catch(_){}
  el.addEventListener('pointermove',move); el.addEventListener('pointerup',up); el.addEventListener('pointercancel',cancel);
}
function move(e){
  if(!drag||e.pointerId!==drag.id) return;
  if(!drag.moved && Math.hypot(e.clientX-drag.sx,e.clientY-drag.sy)>6){
    const r=drag.el.getBoundingClientRect();
    drag.ox=e.clientX-r.left; drag.oy=e.clientY-r.top; drag.moved=true;
    drag.ph=h('div',{style:{width:r.width+'px',height:r.height+'px'}}); drag.el.before(drag.ph);
    drag.el.style.width=r.width+'px'; drag.el.style.height=r.height+'px'; drag.el.classList.add('drag');
    if(selected&&selected!==drag.el){ selected.classList.remove('sel'); selected=null; }
    showPiece(drag.el.dataset.id);
  }
  if(drag.moved){
    drag.el.style.left=(e.clientX-drag.ox)+'px'; drag.el.style.top=(e.clientY-drag.oy)+'px';
    const s=slotAt(e.clientX,e.clientY,drag.el);
    $$('.slot.over').forEach(x=>x!==s&&x.classList.remove('over')); if(s&&!s.classList.contains('filled')) s.classList.add('over');
  }
}
function slotAt(x,y,self){
  const els=document.elementsFromPoint(x,y);
  for(const el of els){ if(el===self) continue; const s=el.closest&&el.closest('.slot'); if(s) return s; }
  return null;
}
function endListeners(el){ el.removeEventListener('pointermove',move); el.removeEventListener('pointerup',up); el.removeEventListener('pointercancel',cancel); }
function up(e){
  if(!drag||e.pointerId!==drag.id) return;
  const d=drag; endListeners(d.el); $$('.slot.over').forEach(x=>x.classList.remove('over'));
  if(!d.moved){ drag=null; select(d.el); return; }
  const s=slotAt(e.clientX,e.clientY,d.el);
  if(s&&!s.classList.contains('filled')){ if(!attempt(d.el,s,true)){ /* giveBack ใน attempt */ } }
  else giveBack(d.el);
  if(!placed[d.el.dataset.id]===false) { /* วางแล้ว */ }
  drag=null;
}
function cancel(e){ if(!drag) return; const d=drag; endListeners(d.el); if(d.moved) giveBack(d.el); drag=null; }
function giveBack(el){
  const ph=drag&&drag.ph; el.classList.remove('drag'); el.style.cssText='';
  if(ph&&ph.parentNode) ph.replaceWith(el); else tray.append(el);
}

/* ---------- hint / solve / reset ---------- */
$('#hint').addEventListener('click',()=>{
  if(solving) return;
  let el=selected;
  if(!el){ const left=V.pieces.filter(p=>!placed[p.id]); if(!left.length) return; el=pieceEls[left[Math.floor(Math.random()*left.length)].id]; select(el); }
  const s=slotEls[el.dataset.id]; if(!s) return;
  s.classList.add('target'); s.scrollIntoView({block:'nearest',behavior:reduce?'auto':'smooth'});
  setTimeout(()=>s.classList.remove('target'),2600);
});
const ORDER=['l1','l2','l3','data','platform','standard','medica','terra','silica','policy','capital'];
$('#solve').addEventListener('click',()=>{
  if(solving) return; solving=true;
  const left=ORDER.filter(id=>!placed[id]);
  left.forEach((id,i)=>setTimeout(()=>{ place(pieceEls[id],slotEls[id]); if(i===left.length-1) solving=false; },reduce?0:i*420));
  if(!left.length) solving=false;
});
$('#reset').addEventListener('click',()=>{
  if(solving) return;
  Object.keys(placed).forEach(id=>{
    const el=pieceEls[id]; el.classList.remove('placed','pop','sel'); el.style.cssText='';
    const s=V.slots.find(x=>x.id===id); slotEls[id].classList.remove('filled','target','shake'); slotEls[id].innerHTML=''; slotEls[id].append(...slotInner(s));
    delete placed[id];
  });
  selected=null; mistakes=0; board.classList.remove('complete'); roof.classList.remove('open'); roof.classList.add('locked');
  $('#rooft').textContent='ต่อให้ครบ 11 ชิ้นเพื่อเปิดภาพปลายทาง'; $('#done').hidden=true; $('#ov').innerHTML='';
  shuffleTray(); progress(); intro();
});

/* ---------- complete ---------- */
const rowDelay={3:0,2:.3,1:.6};
function complete(){
  V.slots.forEach(s=>{ const el=pieceEls[s.id]; el.style.animationDelay=((rowDelay[s.row+s.span-1]||0)+(s.span===3?.9:0))+'s'; });
  board.classList.add('complete');
  setTimeout(()=>{
    roof.classList.remove('locked'); roof.classList.add('open');
    $('#rooft').textContent='เครื่องยนต์เศรษฐกิจใหม่ · ไทยก้าวพ้นกับดักรายได้ปานกลาง';
    burst(); $('#done').hidden=false;
    if(!reduce) $('#done').scrollIntoView({block:'nearest',behavior:'smooth'});
  },reduce?0:1500);
  info.innerHTML=''; info.style.setProperty('--accent','var(--red)');
  info.append(h('h3',null,'ต่อครบแล้ว'),h('p',null,'ชิ้นส่วนทั้ง 11 ชิ้นเชื่อมกันเป็นระบบเดียว ถ้าขาดชิ้นไหน ภาพก็ไม่ครบ'),
    h('p',{class:'muted small'},mistakes?('วางผิด '+mistakes+' ครั้งระหว่างทาง ซึ่งเป็นส่วนหนึ่งของการเรียนรู้'):'วางถูกทุกชิ้นตั้งแต่ครั้งแรก'));
}
function burst(){
  if(reduce) return;
  const ov=$('#ov'), bw=$('#bw').getBoundingClientRect(), rr=roof.getBoundingClientRect();
  ov.setAttribute('viewBox',`0 0 ${bw.width} ${bw.height}`);
  const cols=['var(--red-lt)','var(--green-lt)','var(--blue-lt)','#fff'];
  const cx=bw.width/2, cy=rr.top-bw.top+rr.height/2;
  const ps=Array.from({length:46},(_,i)=>{ const a=Math.random()*Math.PI*2, v=120+Math.random()*260; return {x:cx,y:cy,vx:Math.cos(a)*v,vy:Math.sin(a)*v-60,r:3+Math.random()*4,el:h('circle',{r:4,fill:cols[i%4],opacity:1})}; });
  ps.forEach(p=>ov.append(p.el));
  let t0=performance.now();
  (function step(now){
    const t=(now-t0)/1000;
    ps.forEach(p=>{ const x=p.x+p.vx*t, y=p.y+p.vy*t+260*t*t; p.el.setAttribute('cx',x.toFixed(1)); p.el.setAttribute('cy',y.toFixed(1)); p.el.setAttribute('opacity',Math.max(0,1-t/1.8).toFixed(2)); });
    if(t<1.8) requestAnimationFrame(step); else ov.innerHTML='';
  })(t0);
}

shuffleTray(); intro(); progress();
})();
