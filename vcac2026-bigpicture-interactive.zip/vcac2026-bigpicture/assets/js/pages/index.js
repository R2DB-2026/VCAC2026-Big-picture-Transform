(function(){
const {h,$,$$,Flow,tween,lerp,reduce}=Core;
const V=VF, svg=$('#conv'), cap=$('#cvcap');
const DEF='เลื่อนเมาส์หรือแตะแต่ละจุดเพื่อดูว่าส่งอะไรเข้าสู่การค้นพบ';

/* ---------- convergence diagram ---------- */
const HUB={x:480,y:208,r:58}, FIN={x:945,y:208,r:28};
const SRC=[
  {id:'animal',x:110,y:62, n:'สัตว์', c:'เคสทุกวันจากสุนัข แมว ปศุสัตว์ และสัตว์น้ำ คือข้อมูลโรคที่เกิดตามธรรมชาติ'},
  {id:'human', x:110,y:160,n:'คน', c:'สุขภาพคนได้ประโยชน์เมื่อสัตว์ให้ความรู้ เช่น เรื่องมะเร็งและเชื้อดื้อยา'},
  {id:'env',   x:110,y:258,n:'สิ่งแวดล้อม', c:'ดิน น้ำ อากาศ และก๊าซเรือนกระจก เชื่อมกับสุขภาพของทั้งสัตว์และคน'},
  {id:'tech',  x:110,y:356,n:'เทคโนโลยีและ AI', c:'AI และเซนเซอร์ช่วยเห็นสิ่งที่ตามองไม่เห็น และเร่งการค้นพบ'}
];
const OUT=[
  {id:'medica',x:790,y:76, col:'--blue-lt'},
  {id:'terra', x:790,y:208,col:'--green-lt'},
  {id:'silica',x:790,y:340,col:'--navy-lt'}
];
const cubic=(x0,y0,x1,y1,k)=>`M ${x0} ${y0} C ${x0+k} ${y0}, ${x1-k} ${y1}, ${x1} ${y1}`;
const lineLayer=h('g'), dotLayer=h('g',{'pointer-events':'none'}), nodeLayer=h('g');
svg.append(lineLayer,dotLayer,nodeLayer);

function addLine(d,col,speed,n){
  const p=h('path',{class:'line',d,style:{stroke:'var('+col+')'}}); lineLayer.append(p);
  Flow.add(p,{n:n||3,r:3,speed:speed||70,color:'var('+col+')',layer:dotLayer}); return p;
}
SRC.forEach(s=>addLine(cubic(s.x+26,s.y,HUB.x-HUB.r,HUB.y,170),'--navy-lt',62,3));
OUT.forEach(o=>{
  addLine(cubic(HUB.x+HUB.r,HUB.y,o.x-72,o.y,110),o.col,72,3);
  addLine(cubic(o.x+72,o.y,FIN.x-FIN.r,FIN.y,70),'--red-lt',64,2);
});

function node(g,id,text){
  g.setAttribute('tabindex','0'); g.setAttribute('role','button'); g.classList.add('nd');
  const on=()=>{ cap.textContent=text; }, off=()=>{ cap.textContent=DEF; };
  g.addEventListener('mouseenter',on); g.addEventListener('focus',on); g.addEventListener('click',on);
  g.addEventListener('mouseleave',off); g.addEventListener('blur',off);
  nodeLayer.append(g);
}
SRC.forEach(s=>node(h('g',{transform:`translate(${s.x} ${s.y})`,'aria-label':s.n},
  h('circle',{class:'c',r:24,stroke:'var(--navy-lt)'}),
  h('text',{class:'lb','text-anchor':'middle',y:-36},s.n)),s.id,s.c));
nodeLayer.append(h('circle',{class:'hubring',cx:HUB.x,cy:HUB.y,r:HUB.r}));
node(h('g',{transform:`translate(${HUB.x} ${HUB.y})`,'aria-label':'Veterinary Discovery'},
  h('circle',{class:'c',r:HUB.r,stroke:'var(--red-lt)'}),
  h('text',{class:'lb','text-anchor':'middle',y:-6},'Veterinary'),
  h('text',{class:'lb','text-anchor':'middle',y:14},'Discovery'),
  h('text',{class:'sb','text-anchor':'middle',y:34},'AI + One Health')),'hub','จุดที่ข้อมูลสี่ทางมาพบกันจนกลายเป็นการค้นพบ คือ AI + One Health + มาตรฐานสากล');
OUT.forEach(o=>{
  const f=VF.flagships[o.id];
  node(h('g',{transform:`translate(${o.x} ${o.y})`,'aria-label':f.name},
    h('rect',{class:'c',x:-72,y:-27,width:144,height:54,rx:10,stroke:'var('+o.col+')'}),
    h('text',{class:'lb','text-anchor':'middle',y:-3},f.name),
    h('text',{class:'sb','text-anchor':'middle',y:15},f.tag)),o.id,f.name+': '+f.plain);
});
node(h('g',{transform:`translate(${FIN.x} ${FIN.y})`,'aria-label':'เครื่องยนต์เศรษฐกิจใหม่'},
  h('circle',{class:'c',r:FIN.r,stroke:'var(--red-lt)'}),
  h('text',{class:'sb','text-anchor':'end',x:44,y:-46},'เครื่องยนต์เศรษฐกิจใหม่'),
  h('text',{class:'lb','text-anchor':'middle',y:6,style:{fontSize:'20px'}},'★')),
  'fin','อุตสาหกรรมใหม่มูลค่าสูง เป้าหมายปลายทางคือพาไทยก้าวพ้นกับดักรายได้ปานกลาง');

/* ---------- 4 การเปลี่ยนผ่าน ---------- */
const box=$('#shifts');
const rows=VF.shifts.map(s=>{
  const mk=(o,cls)=>h('div',{class:'st '+cls},h('h3',null,o.t),h('p',null,o.d),h('span',{class:'chip'},o.j));
  const now=mk(s.now,'n'), fut=mk(s.fut,'f');
  const meter=h('i');
  const row=h('div',{class:'shift'},
    h('div',{class:'lab'},s.label,h('div',{class:'meter'},meter)),
    h('div',{class:'stack'},now,fut));
  box.append(row); return {now,fut,meter};
});
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function setDial(v){
  rows.forEach((r,i)=>{
    const vi=clamp((v-i*6)/(100-18)*100,0,100);
    const t=clamp((vi-35)/30,0,1);
    r.now.style.opacity=1-t; r.fut.style.opacity=t;
    r.now.style.pointerEvents=t>.5?'none':'auto'; r.fut.style.pointerEvents=t>.5?'auto':'none';
    r.meter.style.width=vi+'%';
  });
  $('#dial').value=v;
}
setDial(0);
let playing=false, ver=0;
$('#dial').addEventListener('input',e=>{ ver++; playing=false; $('#dplay').textContent='เล่นจากวันนี้ไปอนาคต'; setDial(+e.target.value); });
$('#dplay').addEventListener('click',()=>{
  if(reduce){ setDial(100); return; }
  const my=++ver; playing=true; $('#dplay').textContent='กำลังเล่น';
  setDial(0);
  tween(5200,e=>{ if(my===ver) setDial(e*100); },()=>{ if(my===ver){ playing=false; $('#dplay').textContent='เล่นอีกครั้ง'; } });
});

/* ---------- ทำไมต้องสัตวแพทย์ ---------- */
const T=Terms.T;
const why=[
  ['ป่วยเองตามธรรมชาติ',['สุนัขและแมวเป็นมะเร็งเองในสิ่งแวดล้อมเดียวกับเจ้าของ จึงเป็นสะพานข้อมูลให้เรียนรู้จากกัน (',T('componc','Comparative Oncology'),')'],'discovery.html#bridge','ดูสะพานข้อมูล'],
  ['ข้อมูลหลายระดับ',['สัตวแพทย์ดูได้ตั้งแต่เซลล์ ตัวสัตว์ ฟาร์ม ไปจนถึงระบบนิเวศ ซึ่งตรงกับ AI สามระดับที่ท่านนำเสนอ'],'discovery.html','ดูเดโม AI'],
  ['อยู่กลางสามฝั่ง',['วิชาชีพนี้ผูกสุขภาพคน สัตว์ อาหาร และสิ่งแวดล้อมไว้ด้วยกัน (',T('onehealth','One Health'),') จึงเชื่อมได้ทั้งสามธง'],'onehealth.html','ดูผังระบบนิเวศ']
];
$('#why').append(...why.map(([t,body,href,lab])=>h('div',null,h('h3',null,t),h('p',null,body),h('a',{href},lab))));

/* ---------- เลือกอ่านต่อ ---------- */
const ROWS=[
  ['onehealth.html','ผังระบบนิเวศ One Health','คน สัตว์ สิ่งแวดล้อม เชื่อมกันอย่างไร และสามธง Siam ต่อเข้ากับสัตวแพทย์ตรงไหน','--green'],
  ['pyramid.html','พีระมิด 3 ระดับความเป็นเลิศ','มาตรฐานเป็น "ฐาน" หรือ "เพดาน" สลับดูแล้วเห็นความต่าง','--blue'],
  ['discovery.html','AI ค้นพบอะไรได้บ้าง','เดโมสี่ชิ้น จากภาพชิ้นเนื้อถึงโรคระบาดและโรงงานจุลินทรีย์','--red'],
  ['jigsaw.html','จิ๊กซอว์ภาพใหญ่','ลากชิ้นส่วนทั้ง 11 ชิ้นมาต่อกัน แล้วดูว่าได้อะไร','--red'],
  ['you.html','คุณอยู่ตรงไหนของภาพนี้','เลือกบทบาทของคุณ แล้วดูว่าชิ้นไหนเป็นของคุณและเริ่มทำอะไรได้','--navy'],
  ['glossary.html','พจนานุกรมศัพท์','ศัพท์ในปาฐกถาแปลเป็นภาษาคนพร้อมคำเปรียบเทียบ','--navy']
];
$('#rows').append(...ROWS.map(([href,t,d,c])=>h('a',{href,style:{'--bar':'var('+c+')'}},h('span',{class:'bar'}),h('div',null,h('strong',null,t),h('span',{class:'d'},d)),h('span',{class:'go'},'เปิดดู'))));
Terms.enhance(document);
})();
