(function(){
const {h,$,$$,reduce}=Core; const V=VF;
const TONE={policy:'red',capital:'red',medica:'blue',terra:'green',silica:'navy',data:'navy',platform:'navy',standard:'navy',l1:'blue',l2:'blue',l3:'blue'};
const P={}; V.pieces.forEach(p=>P[p.id]=p);
const mini=$('#mini'), box=$('#you'), pinfo=$('#pinfo'); let cur=null, selPiece=null;
const tiles={};
V.slots.forEach(s=>{
  const p=P[s.id];
  const el=h('div',{class:'mt tr-'+TONE[s.id],tabindex:0,role:'button','aria-label':p.t,style:{gridColumn:s.col,gridRow:s.row+' / span '+s.span}},h('b',null,p.t),h('span',null,p.s));
  const pick=()=>{ selPiece=selPiece===s.id?null:s.id; $$('.mt',mini).forEach(t=>t.classList.toggle('sel',t===el&&selPiece===s.id));
    pinfo.hidden=!selPiece; if(selPiece){ pinfo.innerHTML=''; pinfo.append(h('b',null,p.t+': '),p.e+' ',h('span',{class:'muted'},p.like),' ',h('a',{href:p.page},'อ่านเพิ่ม')); } };
  el.addEventListener('click',pick); el.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); pick(); } });
  mini.append(el); tiles[s.id]=el;
});
function show(id){
  cur=id; const r=V.roles.find(x=>x.id===id);
  $$('#roles button').forEach(b=>b.setAttribute('aria-pressed',b.dataset.id===id?'true':'false'));
  Object.entries(tiles).forEach(([k,el],i)=>{ setTimeout(()=>el.classList.toggle('on',r.pieces.includes(k)),reduce?0:i*45); });
  box.innerHTML=''; box.style.setProperty('--accent','var(--red)');
  box.append(h('h3',null,r.name),h('p',null,r.why),
    h('h4',null,'เริ่มได้ที่ (ภายใน 90 วัน)'),h('ol',null,r.start.map(x=>h('li',null,x))),
    h('h4',null,'คุณจะได้อะไร'),h('div',{class:'gain'},r.gain),
    h('h4',null,'ชิ้นจิ๊กซอว์ของคุณ'),h('div',null,r.pieces.map(k=>h('span',{class:'tag trust'},P[k].t))));
  box.classList.remove('swap'); void box.offsetWidth; box.classList.add('swap');
}
const bar=$('#roles');
V.roles.forEach(r=>bar.append(h('button',{type:'button','data-id':r.id,'aria-pressed':'false',onclick:()=>show(r.id)},r.name)));
show('eng');
})();
