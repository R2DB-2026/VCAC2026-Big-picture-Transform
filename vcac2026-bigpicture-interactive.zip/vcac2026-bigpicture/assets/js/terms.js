/* terms.js — คำที่คลิกแล้วมีคำอธิบายง่ายๆ: <span class="term" data-t="foundation">Foundation Model</span> */
(function(){
'use strict';
const {h}=Core;
const G={}; VF.glossary.forEach(g=>G[g.k]=g);
let pop=null, cur=null, hideT=null;

function build(){
  pop=h('div',{class:'term-pop',role:'tooltip',id:'term-pop',hidden:true});
  document.body.append(pop);
  pop.addEventListener('mouseenter',()=>clearTimeout(hideT));
  pop.addEventListener('mouseleave',()=>schedule());
}
function show(el){
  const g=G[el.dataset.t]; if(!g) return;
  if(!pop) build();
  clearTimeout(hideT); cur=el;
  pop.innerHTML='';
  pop.append(h('b',null,g.t),h('p',null,g.p),h('p',{class:'like'},'เปรียบเหมือน: '+g.a),h('a',{href:'glossary.html#'+g.k},'ดูในพจนานุกรม'));
  pop.hidden=false;
  el.setAttribute('aria-describedby','term-pop');
  const r=el.getBoundingClientRect(), pw=Math.min(340,window.innerWidth-24);
  pop.style.width=pw+'px';
  let x=r.left+window.scrollX, y=r.bottom+window.scrollY+8;
  x=Math.max(12+window.scrollX,Math.min(x,window.scrollX+window.innerWidth-pw-12));
  pop.style.left=x+'px'; pop.style.top=y+'px';
  const ph=pop.offsetHeight;
  if(r.bottom+ph+16>window.innerHeight && r.top>ph+16) pop.style.top=(r.top+window.scrollY-ph-8)+'px';
}
function hide(){ if(!pop) return; pop.hidden=true; if(cur){ cur.removeAttribute('aria-describedby'); cur=null; } }
function schedule(){ clearTimeout(hideT); hideT=setTimeout(hide,220); }

function enhance(root){
  (root||document).querySelectorAll('.term:not([data-ready])').forEach(el=>{
    el.dataset.ready='1';
    el.setAttribute('tabindex','0'); el.setAttribute('role','button');
    el.addEventListener('mouseenter',()=>show(el));
    el.addEventListener('mouseleave',schedule);
    el.addEventListener('focus',()=>show(el));
    el.addEventListener('blur',schedule);
    el.addEventListener('click',e=>{ e.stopPropagation(); if(cur===el&&!pop.hidden) hide(); else show(el); });
    el.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); show(el); } });
  });
}
const T=(key,label)=>h('span',{class:'term','data-t':key},label||(G[key]&&G[key].t)||key);

document.addEventListener('keydown',e=>{ if(e.key==='Escape') hide(); });
document.addEventListener('click',()=>hide());
document.addEventListener('DOMContentLoaded',()=>enhance(document));
window.Terms={enhance,T,G};
})();
